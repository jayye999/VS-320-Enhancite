from flask import Flask, jsonify
import subprocess
import os
import signal
import platform

# from flask_cors import CORS

app = Flask(__name__)

process = None

@app.route('/start-udp', methods=['POST'])
def start_udp():
    global process
    if process is None:
        if platform.system() == 'Windows':
            # you can input your own python.exe path to replace python, make sure the path is correct
            process = subprocess.Popen(['python', './udpport.py'], creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
        else:
            # you can input your own python.exe path to replace python, make sure the path is correct
            process = subprocess.Popen(['python', './udpport.py'], preexec_fn=os.setsid)
        return jsonify({'message': 'UDP script started'}), 200
    return jsonify({'message': 'UDP script already running'}), 400

@app.route('/stop-udp', methods=['POST'])
def stop_udp():
    global process
    if process:
        if platform.system() == 'Windows':
            os.kill(process.pid, signal.CTRL_BREAK_EVENT)
        else:
            os.killpg(os.getpgid(process.pid), signal.SIGTERM)
        process = None
        return jsonify({'message': 'UDP script stopped'}), 200
    return jsonify({'message': 'No UDP script running'}), 400


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
