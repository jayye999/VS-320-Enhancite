import socket
import asyncio
import websockets
websocket_connections = set()
async def udp_to_websocket():
    udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_sock.bind(('0.0.0.0', 12346))
    udp_sock.setblocking(False)  # Make the socket non-blocking

    # Start the WebSocket server
    async with websockets.serve(handler, "localhost", 8765,
ping_timeout=30, close_timeout=10):
        print("WebSocket server started...")
        while True:
            await asyncio.sleep(0.016)  # Small delay to yield control to the loop
            try:
                data, addr = udp_sock.recvfrom(2048)
                print(f"Received UDP data: {data} from {addr}")
                await forward_data(data)
            except BlockingIOError:
                continue  # No data available, continue the loop
            except Exception as e:
                print(f"Unexpected error: {e}")  # Log unexpected errors
async def handler(websocket, path):
   websocket_connections.add(websocket)
   try:
       await websocket.wait_closed()
   finally:
       websocket_connections.remove(websocket)
async def forward_data(data):
    # Convert data to string
    data_str = data.decode()
    # Create a list of websockets that failed to receive the data
    failed_websockets = set()
    # Create a copy of the set for iteration to prevent modification errors
    connections = set(websocket_connections)
    for websocket in connections:
        if websocket.open:
            try:
                await websocket.send(data_str)
            except websockets.exceptions.ConnectionClosed:
                failed_websockets.add(websocket)
    # Remove failed websockets from the original set
    websocket_connections.difference_update(failed_websockets)

if __name__ == "__main__":
    asyncio.run(udp_to_websocket())
