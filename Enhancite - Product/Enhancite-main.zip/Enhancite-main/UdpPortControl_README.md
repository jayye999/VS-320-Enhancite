#  UdpPortControl.py is to make udpport.py only run on ClinicDashboard page.

# make sure you have python

# make sure your python.exe path in UdpPortControl.py is correct, you can set your own path

# pip install websockets

# pip install Flask

# And then the Udpport will start when you use npm start 
