// Import necessary dependencies
import React from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';

// Import your components
import Index from './Index';
import AdminDashboard from './AdminDashboard'; // Assuming you have an AdminDashboard component
import ClinicDashboard from './ClinicDashboard';
import PatientDashboard from './PatientDashboard';
import WifiForm from './WifiForm';

// Define your routes
const App = () => {
    return (
        <Router>
            <Switch>
                <Route path="/AdminDashboard">
                    <AdminDashboard/>
                </Route>
                <Route path="/ClinicDashboard">
                <WifiForm />
                import WifiForm from './WifiForm';
                    <ClinicDashboard/>
                </Route>
                <Route path="/PatientDashboard">
                    <PatientDashboard/>
                </Route>
                <Route path="/">
                    <Index/>
                </Route>
            </Switch>
        </Router>
    );
};

// Render the App component
ReactDOM.render(<App/>, document.getElementById('root'));