import React, {useState} from 'react';
import './Style.css';
import enhanciteImage from './Images/Enhancite_Transparent.png';
import {useHistory} from 'react-router-dom';
import ThresholdPopup from './ThreshHoldPopup';

function PatientDashboard() {
    const history = useHistory();

    const [isThresholdPopupOpen, setIsThresholdPopupOpen] = useState(false);

    const [maxThreshHold, setMaxThreshHold] = useState(0);

    const openThresholdPopup = () => {
        setIsThresholdPopupOpen(true);
    };

    const closePopup = () => {
        setIsThresholdPopupOpen(false);
    };

    const handleLogout = () => {
        // Use the goBack method to navigate back to the previous page
        history.goBack();
    };

    const handleRequestConnection = () => {
        console.log('Request Connection button clicked');
        // Implement your logic for requesting connection here
    };

    return (
        <div className="PatientDashboard">
            <button className="logout-button" onClick={handleLogout}>
                Logout
            </button>

            <div className="Header">
                <div className="banner-image">
                    <img src={enhanciteImage} alt="Enhancite Logo" className="logo-image"/>
                </div>
            </div>

            <main>
                <div className="welcome-label">Welcome To Your very Own Page</div>

                <div className="catch-name-label">Hello there:</div>

                <div className='Instructions-box'>
                    <p>Please wait for your dedicated clinician and follow their instructions when it comes to applying
                       and connecting the emotibit device.

                        <p>1. Make sure everything is turned on</p>
                        <p>2. Make sure the emotibit is connected for file reading</p>
                        <p>3.</p>
                        <p>4</p>
                        <p>5</p>
                        <p>6</p>
                        <p>7</p>
                        <p>8</p>
                    </p>
                </div>


                {/* <div className="vr-name"></div> */}
                {/* <button className="gray-button-patient" onClick={openThresholdPopup}>Thresh Pop Up</button> */}
            </main>
            {isThresholdPopupOpen && (
                <ThresholdPopup maxThreshHold={maxThreshHold} onClose={closePopup}/>
            )}
        </div>
    );
}

export default PatientDashboard;
