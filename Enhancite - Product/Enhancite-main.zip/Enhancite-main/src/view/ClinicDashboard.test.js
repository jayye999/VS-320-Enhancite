import ClinicDashboard from './ClinicDashboard';
import { render, screen, act, fireEvent} from '@testing-library/react';

describe('ClinicDashboard', () => {
  test('displays Live Electrodermal Activity Graph "EA"', () => {
    render(<ClinicDashboard />);
    const eaGraphText = screen.getByText(/Live Electrodermal Activity Graph "EA"/i);
    expect(eaGraphText).toBeInTheDocument();
  });

  test('displays Electrodermal Activity (EA) text value correctly', () => {
    render(<ClinicDashboard />);
    const eaValueText = screen.getByText(/Electrodermal Activity \(EA\)/i);
    expect(eaValueText).toBeInTheDocument();
  });

  test('No data in EA', () => {
    render(<ClinicDashboard />);
    const eaValueElement = screen.getByText(/Electrodermal Activity \(EA\)/i).nextElementSibling;
    const expectedEaValue = 'No data';
    expect(eaValueElement.textContent).toBe(expectedEaValue);
  });

  test('displays Electrodermal Activity (EA) value when not null', () => {
    const testEaValue = 80; 
    render(<ClinicDashboard />); 

    const eventData = {
      category: 'EA',
      value1: testEaValue.toString(),
    };
  
    const mockSocket = new WebSocket('ws://localhost:8765');
    mockSocket.onopen = () => {
      mockSocket.send(JSON.stringify(eventData)); 
    };
  
    setTimeout(() => {
      const eaValueElement = screen.getByText(/Electrodermal Activity \(EA\)/i).nextElementSibling;
      expect(eaValueElement.textContent).toBe(`${testEaValue} seconds`);
    }, 1000); 
  });

  test('displays Live Electrodermal Activity Graph "EA" line chart', () => {
    render(<ClinicDashboard />);
    const eaGraphTitle = screen.getByText(/Live Electrodermal Activity Graph "EA"/i);
    expect(eaGraphTitle).toBeInTheDocument();
  
    // Simulate receiving data for the EA graph
    const testEaData = [
      { x: new Date().toISOString(), y: 70 }, 
      { x: new Date().toISOString(), y: 75 }, 
    ];
  
    act(() => {
      const mockSocket = new WebSocket('ws://localhost:8765');
      mockSocket.onopen = () => {
        mockSocket.send(JSON.stringify({ category: 'EA', value1: '70' }));
        mockSocket.send(JSON.stringify({ category: 'EA', value1: '75' }));
      };
    });
  
    setTimeout(() => {
      testEaData.forEach((dataPoint) => {
        const dataPointElement = screen.getByText(`${dataPoint.y}`); 
        expect(dataPointElement).toBeInTheDocument();
      });
    }, 1000); 
  });

  test('displays Live Electrodermal Level Graph "EL"', () => {
    render(<ClinicDashboard />);
    const elGraphText = screen.getByText(/Live Electrodermal Level Graph "EL"/i);
    expect(elGraphText).toBeInTheDocument();
  });

  test('displays Electrodermal Level (EL) text value correctly', () => {
    render(<ClinicDashboard />);
    const elValueText = screen.getByText(/Electrodermal Level \(EL\)/i);
    expect(elValueText).toBeInTheDocument();
  });

  test('No data in EL', () => {
    render(<ClinicDashboard />);
    const elValueElement = screen.getByText(/Electrodermal Level \(EL\)/i).nextElementSibling;
    const expectedElValue = 'No data';
    expect(elValueElement.textContent).toBe(expectedElValue);
  });

  test('displays Electrodermal Level (EL) value when not null', () => {
    const testElValue = 80; 
    render(<ClinicDashboard />); 

    const eventData = {
      category: 'EL',
      value1: testElValue.toString(),
    };
  
    const mockSocket = new WebSocket('ws://localhost:8765');
    mockSocket.onopen = () => {
      mockSocket.send(JSON.stringify(eventData)); 
    };
  
    setTimeout(() => {
      const elValueElement = screen.getByText(/Electrodermal Level \(EL\)/i).nextElementSibling;
      expect(elValueElement.textContent).toBe(`${testElValue} seconds`);
    }, 1000); 
  });

  test('displays Live Electrodermal Level Graph "EL" line chart', () => {
    render(<ClinicDashboard />);
    const elGraphTitle = screen.getByText(/Live Electrodermal Level Graph "EL"/i);
    expect(elGraphTitle).toBeInTheDocument();
  
    // Simulate receiving data for the EL graph
    const testElData = [
      { x: new Date().toISOString(), y: 70 }, 
      { x: new Date().toISOString(), y: 75 }, 
    ];
  
    act(() => {
      const mockSocket = new WebSocket('ws://localhost:8765');
      mockSocket.onopen = () => {
        mockSocket.send(JSON.stringify({ category: 'EL', value1: '70' }));
        mockSocket.send(JSON.stringify({ category: 'EL', value1: '75' }));
      };
    });
  
    setTimeout(() => {
      testElData.forEach((dataPoint) => {
        const dataPointElement = screen.getByText(`${dataPoint.y}`); 
        expect(dataPointElement).toBeInTheDocument();
      });
    }, 1000); 
  });

  test('displays Live Electrodermal Response Graph "ER"', () => {
    render(<ClinicDashboard />);
    const erGraphText = screen.getByText(/Live Electrodermal Response Graph "ER"/i);
    expect(erGraphText).toBeInTheDocument();
  });

  test('displays Electrodermal Response (ER) text value correctly', () => {
    render(<ClinicDashboard />);
    const erValueText = screen.getByText(/Electrodermal Response \(ER\)/i);
    expect(erValueText).toBeInTheDocument();
  });

  test('No data in ER', () => {
    render(<ClinicDashboard />);
    const erValueElement = screen.getByText(/Electrodermal Response \(ER\)/i).nextElementSibling;
    const expectedErValue = 'No data';
    expect(erValueElement.textContent).toBe(expectedErValue);
  });

  test('displays Electrodermal Response (ER) value when not null', () => {
    const testErValue = 80; 
    render(<ClinicDashboard />); 

    const eventData = {
      category: 'ER',
      value1: testErValue.toString(),
    };
  
    const mockSocket = new WebSocket('ws://localhost:8765');
    mockSocket.onopen = () => {
      mockSocket.send(JSON.stringify(eventData)); 
    };
  
    setTimeout(() => {
      const erValueElement = screen.getByText(/Electrodermal Response \(ER\)/i).nextElementSibling;
      expect(erValueElement.textContent).toBe(`${testErValue} seconds`);
    }, 1000); 
  });

  test('displays Live Electrodermal Response Graph "ER" line chart', () => {
    render(<ClinicDashboard />);
    const erGraphTitle = screen.getByText(/Live Electrodermal Response Graph "ER"/i);
    expect(erGraphTitle).toBeInTheDocument();
  
    // Simulate receiving data for the ER graph
    const testErData = [
      { x: new Date().toISOString(), y: 70 }, 
      { x: new Date().toISOString(), y: 75 }, 
    ];
  
    act(() => {
      const mockSocket = new WebSocket('ws://localhost:8765');
      mockSocket.onopen = () => {
        mockSocket.send(JSON.stringify({ category: 'ER', value1: '70' }));
        mockSocket.send(JSON.stringify({ category: 'ER', value1: '75' }));
      };
    });
  
    setTimeout(() => {
      testErData.forEach((dataPoint) => {
        const dataPointElement = screen.getByText(`${dataPoint.y}`); 
        expect(dataPointElement).toBeInTheDocument();
      });
    }, 1000); 
  });

  test('displays Live Skin Conductance Response Frequency Graph "SF"', () => {
    render(<ClinicDashboard />);
    const sfGraphText = screen.getByText(/Live Skin Conductance Response Frequency Graph "SF"/i);
    expect(sfGraphText).toBeInTheDocument();
  });

  test('displays Skin Conductance Response Frequency (SF) text value correctly', () => {
    render(<ClinicDashboard />);
    const sfValueText = screen.getByText(/Skin Conductance Response Frequency \(SF\)/i);
    expect(sfValueText).toBeInTheDocument();
  });

  test('No data in SF', () => {
    render(<ClinicDashboard />);
    const sfValueElement = screen.getByText(/Skin Conductance Response Frequency \(SF\)/i).nextElementSibling;
    const expectedSfValue = 'No data';
    expect(sfValueElement.textContent).toBe(expectedSfValue);
  });

  test('displays Skin Conductance Response Frequency (SF) value when not null', () => {
    const testSfValue = 80; 
    render(<ClinicDashboard />); 

    const eventData = {
      category: 'SF',
      value1: testSfValue.toString(),
    };
  
    const mockSocket = new WebSocket('ws://localhost:8765');
    mockSocket.onopen = () => {
      mockSocket.send(JSON.stringify(eventData)); 
    };
  
    setTimeout(() => {
      const sfValueElement = screen.getByText(/Skin Conductance Response Frequency \(SF\)/i).nextElementSibling;
      expect(sfValueElement.textContent).toBe(`${testSfValue} seconds`);
    }, 1000); 
  });

  test('displays Live Skin Conductance Response Frequency Graph "SF" line chart', () => {
    render(<ClinicDashboard />);
    const sfGraphTitle = screen.getByText(/Live Skin Conductance Response Frequency Graph "SF"/i);
    expect(sfGraphTitle).toBeInTheDocument();
  
    // Simulate receiving data for the SF graph
    const testSfData = [
      { x: new Date().toISOString(), y: 70 }, 
      { x: new Date().toISOString(), y: 75 }, 
    ];
  
    act(() => {
      const mockSocket = new WebSocket('ws://localhost:8765');
      mockSocket.onopen = () => {
        mockSocket.send(JSON.stringify({ category: 'SF', value1: '70' }));
        mockSocket.send(JSON.stringify({ category: 'SF', value1: '75' }));
      };
    });
  
    setTimeout(() => {
      testSfData.forEach((dataPoint) => {
        const dataPointElement = screen.getByText(`${dataPoint.y}`); 
        expect(dataPointElement).toBeInTheDocument();
      });
    }, 1000); 
  });

  test('displays Live Skin Conductance Response Amplitude Graph "SA"', () => {
    render(<ClinicDashboard />);
    const saGraphText = screen.getByText(/Live Skin Conductance Response Amplitude Graph "SA"/i);
    expect(saGraphText).toBeInTheDocument();
  });

  test('displays Skin Conductance Response Amplitude (SA) text value correctly', () => {
    render(<ClinicDashboard />);
    const saValueText = screen.getByText(/Skin Conductance Response Amplitude \(SA\)/i);
    expect(saValueText).toBeInTheDocument();
  });

  test('No data in SA', () => {
    render(<ClinicDashboard />);
    const saValueElement = screen.getByText(/Skin Conductance Response Amplitude \(SA\)/i).nextElementSibling;
    const expectedSaValue = 'No data';
    expect(saValueElement.textContent).toBe(expectedSaValue);
  });

  test('displays Skin Conductance Response Amplitude (SA) value when not null', () => {
    const testSaValue = 80; 
    render(<ClinicDashboard />); 

    const eventData = {
      category: 'SA',
      value1: testSaValue.toString(),
    };
  
    const mockSocket = new WebSocket('ws://localhost:8765');
    mockSocket.onopen = () => {
      mockSocket.send(JSON.stringify(eventData)); 
    };
  
    setTimeout(() => {
      const saValueElement = screen.getByText(/Skin Conductance Response Amplitude \(SA\)/i).nextElementSibling;
      expect(saValueElement.textContent).toBe(`${testSaValue} seconds`);
    }, 1000); 
  });

  test('displays Live Skin Conductance Response Amplitude Graph "SA" line chart', () => {
    render(<ClinicDashboard />);
    const saGraphTitle = screen.getByText(/Live Skin Conductance Response Amplitude Graph "SA"/i);
    expect(saGraphTitle).toBeInTheDocument();
  
    // Simulate receiving data for the SA graph
    const testSaData = [
      { x: new Date().toISOString(), y: 70 }, 
      { x: new Date().toISOString(), y: 75 }, 
    ];
  
    act(() => {
      const mockSocket = new WebSocket('ws://localhost:8765');
      mockSocket.onopen = () => {
        mockSocket.send(JSON.stringify({ category: 'SA', value1: '70' }));
        mockSocket.send(JSON.stringify({ category: 'SA', value1: '75' }));
      };
    });
  
    setTimeout(() => {
      testSaData.forEach((dataPoint) => {
        const dataPointElement = screen.getByText(`${dataPoint.y}`); 
        expect(dataPointElement).toBeInTheDocument();
      });
    }, 1000); 
  });

  test('displays Live Skin Conductance Response Rise Time Graph "SR"', () => {
    render(<ClinicDashboard />);
    const srGraphText = screen.getByText(/Live Skin Conductance Response Rise Time Graph "SR"/i);
    expect(srGraphText).toBeInTheDocument();
  });

  test('displays Skin Conductance Response Rise Time (SR) text value correctly', () => {
    render(<ClinicDashboard />);
    const srValueText = screen.getByText(/Skin Conductance Response Rise Time \(SR\)/i);
    expect(srValueText).toBeInTheDocument();
  });

  test('No data in SR', () => {
    render(<ClinicDashboard />);
    const srValueElement = screen.getByText(/Skin Conductance Response Rise Time \(SR\)/i).nextElementSibling;
    const expectedSrValue = 'No data';
    expect(srValueElement.textContent).toBe(expectedSrValue);
  });

  test('displays Skin Conductance Response Rise Time (SR) value when not null', () => {
    const testSrValue = 80; 
    render(<ClinicDashboard />); 

    const eventData = {
      category: 'SR',
      value1: testSrValue.toString(),
    };
  
    const mockSocket = new WebSocket('ws://localhost:8765');
    mockSocket.onopen = () => {
      mockSocket.send(JSON.stringify(eventData)); 
    };
  
    setTimeout(() => {
      const srValueElement = screen.getByText(/Skin Conductance Response Rise Time \(SR\)/i).nextElementSibling;
      expect(srValueElement.textContent).toBe(`${testSrValue} seconds`);
    }, 1000); 
  });

  test('displays Live Skin Conductance Response Rise Time Graph "SR" line chart', () => {
    render(<ClinicDashboard />);
    const srGraphTitle = screen.getByText(/Live Skin Conductance Response Rise Time Graph "SR"/i);
    expect(srGraphTitle).toBeInTheDocument();
  
    // Simulate receiving data for the SR graph
    const testSrData = [
      { x: new Date().toISOString(), y: 70 }, 
      { x: new Date().toISOString(), y: 75 }, 
    ];
  
    act(() => {
      const mockSocket = new WebSocket('ws://localhost:8765');
      mockSocket.onopen = () => {
        mockSocket.send(JSON.stringify({ category: 'SR', value1: '70' }));
        mockSocket.send(JSON.stringify({ category: 'SR', value1: '75' }));
      };
    });
  
    setTimeout(() => {
      testSrData.forEach((dataPoint) => {
        const dataPointElement = screen.getByText(`${dataPoint.y}`); 
        expect(dataPointElement).toBeInTheDocument();
      });
    }, 1000); 
  });

  test('displays Live Heart Rate Graph "HR"', () => {
    render(<ClinicDashboard />);
    const hrGraphText = screen.getByText(/Live Heart Rate Graph "HR"/i);
    expect(hrGraphText).toBeInTheDocument();
  });

  test('displays Heart Rate (HR) text value correctly', () => {
    render(<ClinicDashboard />);
    const hrValueText = screen.getByText(/Heart Rate \(HR\)/i);
    expect(hrValueText).toBeInTheDocument();
  });

  test('No data in HR', () => {
    render(<ClinicDashboard />);
    const hrValueElement = screen.getByText(/Heart Rate \(HR\)/i).nextElementSibling;
    const expectedHrValue = 'No data';
    expect(hrValueElement.textContent).toBe(expectedHrValue);
  });

  test('displays Heart Rate (HR) value when not null', () => {
    const testHrValue = 80; 
    render(<ClinicDashboard />); 

    const eventData = {
      category: 'HR',
      value1: testHrValue.toString(),
    };
  
    const mockSocket = new WebSocket('ws://localhost:8765');
    mockSocket.onopen = () => {
      mockSocket.send(JSON.stringify(eventData)); 
    };
  
    setTimeout(() => {
      const hrValueElement = screen.getByText(/Heart Rate \(HR\)/i).nextElementSibling;
      expect(hrValueElement.textContent).toBe(`${testHrValue} bpm`);
    }, 1000); 
  });

  test('displays Live Heart Rate Graph "HR" line chart', () => {
    render(<ClinicDashboard />);
    const hrGraphTitle = screen.getByText(/Live Heart Rate Graph "HR"/i);
    expect(hrGraphTitle).toBeInTheDocument();
  
    // Simulate receiving data for the HR graph
    const testHrData = [
      { x: new Date().toISOString(), y: 70 }, 
      { x: new Date().toISOString(), y: 75 }, 
    ];
  
    act(() => {
      const mockSocket = new WebSocket('ws://localhost:8765');
      mockSocket.onopen = () => {
        mockSocket.send(JSON.stringify({ category: 'HR', value1: '70' }));
        mockSocket.send(JSON.stringify({ category: 'HR', value1: '75' }));
      };
    });
  
    setTimeout(() => {
      testHrData.forEach((dataPoint) => {
        const dataPointElement = screen.getByText(`${dataPoint.y}`); 
        expect(dataPointElement).toBeInTheDocument();
      });
    }, 1000); 
  });

});
