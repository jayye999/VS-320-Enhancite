import React, {useState} from 'react';
import UserIcon from './Images/UserIcon.png';
import PasswordIcon from './Images/PasswordIcon.jpg';
import PhoneIcon from './Images/PhoneIcon.png';
import MailIcon from './Images/MailIcon.png';
import NamesIcon from './Images/NamesIcon.png';
import axios from 'axios';

function SignUpPopup({isOpen, onClose}) {
    const [formData, setFormData] = useState({
        emotibitId: '',
        password: '',
        clinicianId: '',
        email: '',
        firstName: '',
        lastName: '',
    });

    const handleChange = (e) => {
        const {name, value} = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    // Define the URL of your API endpoint
    const apiUrl = 'http://3.27.158.164:8080/auth/patient';

    const headers = {
        'Content-Type': 'application/json'
    };

    const handleSignUp = () => {
        //save data
        localStorage.setItem('userDetails', JSON.stringify(formData));
        console.log('User details saved:', formData);

        // Make the POST request to Patient Registration
        axios.post(apiUrl, formData, {headers})
            .then(response => {
                if (response.status === 200) {
                    console.log('Patient Registration successful');
                    // You can access user data from response.data, if provided
                    onClose();
                } else {
                    alert('Patient Registration failed');
                    console.log('Patient Registration failed');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Patient Registration failed');
            });
    };

    const labelStyle = {fontFamily: 'sans-serif'};
    const buttonStyle = {fontFamily: 'sans-serif'};

    return (
        <div className="popup-container">
            {isOpen && (
                <div className="popup-content">
                    <h2 className="SignUpLabel4Popup">Sign Up</h2>
                    <div className="form-group">
                        <img src={UserIcon} alt="User Icon"
                             style={{width: '20px', height: '20px', marginRight: '10px'}}/>

                        <label htmlFor="emotibitId" style={labelStyle}>
                            emotibitId:
                        </label>
                        <input
                            type="text"
                            id="emotibitId"
                            name="emotibitId"
                            value={formData.emotibitId}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="form-group">
                        <img src={PasswordIcon} alt="Password Icon"
                             style={{width: '20px', height: '20px', marginRight: '10px'}}/>
                        <label htmlFor="password" style={labelStyle}>
                            Password:
                        </label>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            value={formData.password}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="form-group">
                        <img src={PhoneIcon} alt="Phone Icon"
                             style={{width: '20px', height: '20px', marginRight: '10px'}}/>
                        <label htmlFor="clinicianId" style={labelStyle}>
                            clinicianId:
                        </label>
                        <input
                            type="text"
                            id="clinicianId"
                            name="clinicianId"
                            value={formData.clinicianId}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="form-group">
                        <img src={MailIcon} alt="Mail Icon"
                             style={{width: '20px', height: '20px', marginRight: '10px'}}/>
                        <label htmlFor="emailAddress" style={labelStyle}>
                            Email:
                        </label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="form-group">
                        <img src={NamesIcon} alt="names Icon"
                             style={{width: '20px', height: '20px', marginRight: '10px'}}/>
                        <label htmlFor="firstName" style={labelStyle}>
                            First Name:
                        </label>
                        <input
                            type="text"
                            id="firstName"
                            name="firstName"
                            value={formData.firstName}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="form-group">
                        <img src={NamesIcon} alt="names Icon"
                             style={{width: '20px', height: '20px', marginRight: '10px'}}/>
                        <label htmlFor="lastName" style={labelStyle}>
                            Last Name:
                        </label>
                        <input
                            type="text"
                            id="lastName"
                            name="lastName"
                            value={formData.lastName}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="form-buttons">
                        <button
                            className="create-account-button"
                            onClick={handleSignUp}
                            style={buttonStyle}
                        >
                            Create Account
                        </button>
                        <button className="close-button" onClick={onClose} style={buttonStyle}>
                            Close
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}

export default SignUpPopup;
