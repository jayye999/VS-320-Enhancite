import React, { useEffect, useState } from 'react';
import enhanciteImage from './Enhancite_Transparent.png';
import './Style.css'; // Import your custom CSS file
import axios from 'axios';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import LineChartComponent from './LineChartComponent';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
import { useHistory } from 'react-router-dom';

function ClinicDashboard() {
  const [udpData, setUdpData] = useState([]); // State to store UDP data
  //SFvalue
  const [scrfValue, setScrfValue] = useState(null);//SFvalue
  const [scrfValue1, setScrfValue1] = useState([]);//SFvaluegraph

  //SAvalue
  const [scraValue, setScraValue] = useState(null);//SAvalue
  const [scraValue1, setScraValue1] = useState([]); //SAgraph

  //SRvalue
  const [scrrValue, setScrrValue] = useState(null); //SRvalue
  const [scrrValue1, setScrrValue1] = useState([]);//SRvaluegraph


  //HR
  const [hrValue, setHrValue] = useState(null);// HR value
  const [hrValue1, setHrValue1] = useState([]);// HR graph
  const [hrLineColor, setHrLineColor] = useState('#8884d8');  // Default color for the HR graph line  

  //HR Blinking
  const hrClass = hrValue > 100 ? 'blinking-red ' : ''; // Heart rate blinking-red 
  const hrClass2= hrValue < 50 ? 'blinking-blue ' : ''; // Heart rate blinking-blue


  //Accelerometer X (AX)
  const [axValue, setAxValue] = useState(null);// AX value 
  const [axValue1, setAxValue1] = useState([]);// AX graph

  //Accelerometer Y (AY)
  const [ayValue, setAyValue] = useState(null);// AY value 
  const [ayValue1, setAyValue1] = useState([]);// AY graph


  //Accelerometer Z (AZ)
  const [azValue, setAzValue] = useState(null);// AZ value 
  const [azValue1, setAzValue1] = useState([]);// AZ graph


  //Message
  const [udpMessages, setUdpMessages] = useState([]);


  //EAValue
  const [edaValue, setEdaValue] = useState(null); // EAValue
  const [edaValue1, setEdaValue1] = useState([]); // EAgraph

  //ELvalue
  const [edlValue, setEdlValue] = useState(null); // ELvalue
  const [edlValue1, setEdlValue1] = useState([]);// ELgraph
  
  //THvalue
  const [thValue, setThValue] = useState(null); //THvalue, we will not receive TH data, can be change to another data stream
  const [thValue1, setThValue1] = useState([]); //THgraph

  const [timestamps, setTimestamps] = useState([]);
  const scalingFactor = 10000;  // Scale EA values to a range of 0 to 10000

  const history = useHistory();
  // const socketIo = io('http://localhost:8765');
  const handleLogout = () => {
    history.goBack();
  };

  const generateSessionId = () => {
    const timestamp = Date.now();
    const maxRandomPart = 99999;
    const randomPart = Math.floor(Math.random() * maxRandomPart);
    console.log(timestamp * 1000000 + randomPart);
  
    return timestamp * 1000000 + randomPart; 
  };
  
  const sendSessionDataToTables = async () => {
    const sessionId = generateSessionId(); // Gen session ID

    for (const data of udpData) {
      switch (data.category) {
        case 'HR':
          if (!isNaN(data.value1)) {
            const heartRatePayload = {
              sessionId: sessionId,
              dateTimeRecorded: timestamps[data.id],
              patientId: 1, // Assuming patient ID is always 1 (TODO: CHANGE TO GET PATIENT_ID)
              value: data.value1
            };
            await sendDataToTable('hr', heartRatePayload)
          }
          break;
        case 'SF':
          if (!isNaN(data.value1)) {
            const skinConductanceResponseFrequencyPayload = {
              sessionId: sessionId,
              dateTimeRecorded: timestamps[data.id],
              patientId: 1, // Assuming patient ID is always 1 (TODO: CHANGE TO GET PATIENT_ID)
              value: data.value1
            };
            await sendDataToTable('scrf', skinConductanceResponseFrequencyPayload)
          }
          break;
        case 'ER':
          if (!isNaN(data.value1)) {
            const electrodermalResponsePayload = {
              sessionId: sessionId,
              dateTimeRecorded: timestamps[data.id],
              patientId: 1, // Assuming patient ID is always 1 (TODO: CHANGE TO GET PATIENT_ID)
              value: data.value1
            };
            await sendDataToTable('edr', electrodermalResponsePayload)
          }
          break;
        case 'EL':
          if (!isNaN(data.value1)) {
            const electrodermalLevelPayload = {
              sessionId: sessionId,
              dateTimeRecorded: timestamps[data.id],
              patientId: 1, // Assuming patient ID is always 1 (TODO: CHANGE TO GET PATIENT_ID)
              value: data.value1
            };
            await sendDataToTable('edl', electrodermalLevelPayload)
          }
          break;
        case 'T1':
          if (!isNaN(data.value1)) {
            const temperaturePayload = {
              sessionId: sessionId,
              dateTimeRecorded: timestamps[data.id],
              patientId: 1, // Assuming patient ID is always 1 (TODO: CHANGE TO GET PATIENT_ID)
              value: data.value1
            };
            await sendDataToTable('t1', temperaturePayload)
          }
          break;
        case 'BI':
          if (!isNaN(data.value1)) {
            const heartRateIntervalPayload = {
              sessionId: sessionId,
              dateTimeRecorded: timestamps[data.id],
              patientId: 1, // Assuming patient ID is always 1 (TODO: CHANGE TO GET PATIENT_ID)
              value: data.value1
            };
            await sendDataToTable('bi', heartRateIntervalPayload)
          }
          break;
        default:
          console.log(`Unknown category: ${data.category}. Skipping...`);
      }
    }
    alert('Finished Export');
  };

  async function sendDataToTable(tableName, payload) {
    try {
      await axios.post(`http://3.27.158.164:8080/datastream/${tableName}`, payload);
      console.log(`${tableName} data sent successfully:`, payload);
    } catch (error) {
      if (axios.isAxiosError(error)) {
        // Handle Axios errors
        console.error('Request failed:', error.message);
        console.error('Request config:', error.config);
        if (error.response) {
          console.error('Response status:', error.response.status);
          console.error('Response data:', error.response.data);
        }
      } else {
        // Handle other errors
        console.error(`Error sending ${tableName} data:`, error.message);
      }
      
    }
  }
  

  useEffect(() => {

    // Start the UDP script when the component mounts
    axios.post('http://localhost:5000/start-udp')
      .then(response => console.log(response.data.message))
      .catch(error => console.error('Error starting UDP script:', error));
      
    const socket = new WebSocket('ws://localhost:8765');

    socket.onmessage = (event) => {
      const message = event.data;
      const fields = message.split(',');
      const newData = {
        id: fields[0],
        sequence: fields[1],
        typeCode: fields[2],
        category: fields[3],
        flag: fields[4],
        quality: fields[5],
        value1: parseFloat(fields[6]),
        value2: fields[7]

        
      };


      switch (newData.category) {
        case 'SF':
          if (!isNaN(newData.value1)) 
            setScrfValue(newData.value1);
            setScrfValue1(prevData => {
            const newDataPoint = { x: new Date().toISOString(), y: newData.value1 };
            // Keep only the latest 50 data points
            return [...prevData, newDataPoint].slice(-50);
          });
          break;
        case 'SA':
          if (!isNaN(newData.value1)) 
            setScraValue(newData.value1);
            setScraValue1(prevData => {
            const newDataPoint = { x: new Date().toISOString(), y: newData.value1 };
            // Keep only the latest 50 data points
            return [...prevData, newDataPoint].slice(-50);
          });
          break;
        case 'SR':
          if (!isNaN(newData.value1)) 
            setScrrValue(newData.value1);
            setScrrValue1(prevData => {
            const newDataPoint = { x: new Date().toISOString(), y: newData.value1 };
            // Keep only the latest 50 data points
            return [...prevData, newDataPoint].slice(-50);
          });
        break;
        case 'HR':

        //Set heart rate  
        const heartRate = newData.value1;
        if (!isNaN(heartRate)) {

          //heart rate data
          setHrValue(heartRate);

           //heart rate graph
          setHrValue1(prevData => {   
            const newDataPoint = { x: new Date().toISOString(), y: heartRate };
            return [...prevData, newDataPoint].slice(-20);  // Keep only the latest 20 data points
          });
          // Update the line color based on heart rate
          if (heartRate > 100 ) {
            setHrLineColor('#ff0000'); // Set color to red if heart rate is over 100
            const currentTime = new Date().toLocaleTimeString();
            const warningMessage = `Warning: High Heart Rate of ${heartRate} bpm at ${currentTime}`;
            setUdpMessages(prevMessages => [...prevMessages, warningMessage]);
            //Low heart rate
          }else if(heartRate < 50 ){
            setHrLineColor('#87CEFA'); // Set color to blue if heart rate is lower 50
            const currentTime = new Date().toLocaleTimeString();
            const warningMessage = `Warning: low Heart Rate of ${heartRate} bpm at ${currentTime}`;
            setUdpMessages(prevMessages => [...prevMessages, warningMessage]);
          }else {
            setHrLineColor('#90EE90'); // Set to default color otherwise
          } 
        }
        break;
        case 'EA':
          if (!isNaN(newData.value1)){
            setEdaValue(newData.value1);
            setEdaValue1(prevData => {
              const newDataPoint = { x: new Date().toISOString(), y: newData.value1 };
              // Keep only the latest 50 data points
              return [...prevData, newDataPoint].slice(-50);
            });
          } 
            
          break;
        case 'EL':
          if (!isNaN(newData.value1)) 
            setEdlValue(newData.value1);
            setEdlValue1(prevData => {
            const newDataPoint = { x: new Date().toISOString(), y: newData.value1 };
            // Keep only the latest 50 data points
            return [...prevData, newDataPoint].slice(-50);
          });

          break;
        case 'TH':
          if (!isNaN(newData.value1)){
            setThValue(newData.value1);
            setThValue1(prevData => {
              const newDataPoint = { x: new Date().toISOString(), y: newData.value1.toFixed(2) }; // decimal 2
              // Keep only the latest 50 data points
              return [...prevData, newDataPoint].slice(-50);
            });
          }
        case 'AX':
          if (!isNaN(newData.value1)){
            setAxValue(newData.value1);
            setAxValue1(prevData => {
              const newDataPoint = { x: new Date().toISOString(), y: newData.value1}; 
              // Keep only the latest 50 data points
              return [...prevData, newDataPoint].slice(-50);
            });
          }
        case 'AY':
          if (!isNaN(newData.value1)){
            setAyValue(newData.value1);
            setAyValue1(prevData => {
              const newDataPoint = { x: new Date().toISOString(), y: newData.value1 }; 
              // Keep only the latest 50 data points
              return [...prevData, newDataPoint].slice(-50);
            });
          }
        case 'AZ':
          if (!isNaN(newData.value1)){
            setAzValue(newData.value1);
            setAzValue1(prevData => {
              const newDataPoint = { x: new Date().toISOString(), y: newData.value1 }; 
              // Keep only the latest 50 data points
              return [...prevData, newDataPoint].slice(-50);
            });
          }    

        default:
          break;
      }
      setTimestamps((prevTimestamps) => [...prevTimestamps, new Date().toISOString()]);
      setUdpData((prevData) => [...prevData, newData]);
    };

    socket.onopen = () => {
      console.log('WebSocket connection established');
    };

    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    socket.onclose = (event) => {
      console.log('WebSocket connection closed', event.wasClean ? 'cleanly' : 'unexpectedly');
      console.log('Close code:', event.code, 'Reason:', event.reason);
    };

  return () => {
    // Stop the UDP script when the component unmounts
    axios.post('http://localhost:5000/stop-udp')
      .then(response => console.log(response.data.message))
      .catch(error => console.error('Error stopping UDP script:', error));
    socket.close();
    
  };
}, []);


  return (
    <>
      <div className="custom-header">
        <img src={enhanciteImage} alt="Enhancite Logo" className="logo-image" />
      </div>
      <div className="button-container-b">
        <div className="btn-group">
          <button className="btn btn-danger" onClick={handleLogout}>
            Logout
          </button>
          <button className="btn btn-primary ml-2" onClick={sendSessionDataToTables}>
            Export Data
          </button>
        </div>
      </div>

      <div className="container mt-3">
        {/* Container to hold all data displays */}
        <div className="data-container">
          {/* UDP Data Section */}
          <section className="row">
            <div className="col-md-12">
              <div className="category">
                <div className="card">
                  <div className="card-body">
                    <h5 className="card-title">Warning message</h5>
                    <div className="scrollable-box"> {/* Use the scrollable-box class here */}
                    {udpMessages.map((message, index) => (
                    <div key={index}>{message}</div>
                   ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Other Data Displays */}
          {/*EL*/}
          <div className="container mt-3"></div>
          <section className="row">
          <div className="container">
          <div className="row">
            <div className="col-md-4">
              <div className="category">
                <div className="card">
                  <div className="card-body1">
                    <h5 className="card-title">Electrodermal Activity (EA)</h5>
                    <p className="card-text">{edaValue ? `${edaValue} units` : "No data"}</p>
                  </div>
                </div> 
              </div>
            </div>

            {/*EA*/}
            <div className="col-md-4">
              <div className="category">
                <div className="card">
                  <div className="card-body1">
                    <h5 className="card-title">Electrodermal Level (EL)</h5>
                    <p className="card-text">{edlValue ? `${edlValue} units` : "No data"}</p>
                  </div>
                </div>
              </div>
            </div>

            {/*TH*/}
            <div className="col-md-4">
              <div className="category">
                <div className="card">
                  <div className="card-body1">
                    <h5 className="card-title">Temperature (TH)</h5>
                    <p className="card-text">{thValue ? `${thValue} °C` : "No data"}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
     


            

    {/* {Graph EA,EL,TH} */}
    <div className="container mt-2">
    <div className="row">
        <div className="col-md-4">
            <div className="category">
                <div className="card">
                    <div className="card-body">
                        <h5 className="card-title">Live Electrodermal Activity Graph "EA"</h5>
                        <div className="chart-container">
                            <LineChart width={350} height={280} data={edaValue1}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="x" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="y" strokeWidth={2} />
                            </LineChart>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div className="col-md-4">
            <div className="category">
                <div className="card">
                    <div className="card-body">
                        <h5 className="card-title">Live Electrodermal Level Graph "EL"</h5>
                        <div className="chart-container">
                            <LineChart width={350} height={280} data={edlValue1}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="x" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="y" strokeWidth={2} />
                            </LineChart>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div className="col-md-4">
            <div className="category">
                <div className="card">
                    <div className="card-body">
                        <h5 className="card-title">Live Electrodermal Activity Graph "TH"</h5>
                        <div className="chart-container">
                            <LineChart width={350} height={280} data={thValue1}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="x" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="y" strokeWidth={2} />
                            </LineChart>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>





            {/* Display for SF, SA, SR, HR */}
            {/* {leave a little space } */}
            <div className="container mt-2"></div> 
            <div className="col-md-4">
              <div className="category">
                <div className="card">
                  <div className="card-body2">
                    <h5 className="card-title">Skin Conductance Response (SF) Frequency</h5>
                    <p className="card-text">{scrfValue ? `${scrfValue} Hz` : "No data"}</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="category">
                <div className="card">
                  <div className="card-body2">
                    <h5 className="card-title">Skin Conductance Response (SA) Amplitude</h5>
                    <p className="card-text">{scraValue ? `${scraValue} units` : "No data"}</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="category">
                <div className="card">
                  <div className="card-body2">
                    <h5 className="card-title">Skin Conductance Response (SR) Rise Time</h5>
                    <p className="card-text">{scrrValue ? `${scrrValue} seconds` : "No data"}</p>
                  </div>
                </div>
              </div>
            </div>

    {/* {Graph SCR: SF,SA,SR} */}
    <div className="container mt-2">
    <div className="row">
        <div className="col-md-4">
            <div className="category">
                <div className="card">
                    <div className="card-body">
                        <h5 className="card-title">Live Electrodermal Activity Graph "SF"</h5>
                        <div className="chart-container">
                            <LineChart width={350} height={280} data={scrfValue1}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="x" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="y" strokeWidth={2} />
                            </LineChart>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div className="col-md-4">
            <div className="category">
                <div className="card">
                    <div className="card-body">
                        <h5 className="card-title">Live Electrodermal Level Graph "SA"</h5>
                        <div className="chart-container">
                            <LineChart width={350} height={280} data={scraValue1}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="x" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="y" strokeWidth={2} />
                            </LineChart>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div className="col-md-4">
            <div className="category">
                <div className="card">
                    <div className="card-body">
                        <h5 className="card-title">Live Electrodermal Activity Graph "SR"</h5>
                        <div className="chart-container">
                            <LineChart width={350} height={280} data={scrrValue1}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="x" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="y" strokeWidth={2} />
                            </LineChart>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


              {/* {Heat rate} */}{/* {little space} */}
              <div className="container mt-2"></div> 
              <div className="col-md-4">
                <div className="category">
                  <div className="card">
                    <div className="card-body3">
                      <h5 className="card-title">Heart Rate (HR)</h5>
                      <p className="card-text">{hrValue ? `${hrValue} bpm` : "No data"}</p>
                    </div>
                  </div>
                </div>
              </div>
              {/* {Accelerometer X} */}
              <div className="col-md-4">
                <div className="category">
                  <div className="card">
                    <div className="card-body4">
                      <h5 className="card-title">Accelerometer X (AX)</h5>
                      <p className="card-text">{axValue ? `${axValue} unit` : "No data"}</p>
                    </div>
                  </div>
                </div>
              </div>
              {/* {Accelerometer Y} */}
              <div className="col-md-4">
                <div className="category">
                  <div className="card">
                    <div className="card-body4">
                      <h5 className="card-title">Accelerometer Y (AY)</h5>
                      <p className="card-text">{ayValue ? `${ayValue} unit` : "No data"}</p>
                    </div>
                  </div>
                </div>
              </div>
            
              
            {/* {Heartrate graph} */}
            <div className="container mt-2">
            <div className="row">
            <div className="col-md-4">
            <div className="category">
                <div className="card">
                    <div className={`card-body ${hrClass} ${hrClass2} `}>
                        <h5 className="card-title">Live Electrodermal Activity Graph "HR"</h5>
                        <div className="chart-container">
                            <LineChart width={350} height={280} data={hrValue1}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="x" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="y" stroke={hrLineColor} strokeWidth={3}/>
                            </LineChart>
                        </div>
                    </div>
              </div>
            </div>
        </div>
        {/* {Accelerometer X} */}            
        <div className="col-md-4">
            <div className="category">
                <div className="card">
                    <div className={"card-body"}>
                        <h5 className="card-title">Live Electrodermal Activity Graph "AX"</h5>
                        <div className="chart-container">
                            <LineChart width={350} height={280} data={axValue1}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="x" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="y" strokeWidth={2}/>
                            </LineChart>
                        </div>
                    </div>
              </div>
            </div>
        </div>
        {/* {Accelerometer Y} */}             
        <div className="col-md-4">
            <div className="category">
                <div className="card">
                    <div className={"card-body"}>
                        <h5 className="card-title">Live Electrodermal Activity Graph "AY"</h5>
                        <div className="chart-container">
                            <LineChart width={350} height={280} data={ayValue1}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="x" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="y" strokeWidth={2}/>
                            </LineChart>
                        </div>
                    </div>
              </div>
            </div>
        </div>

        {/* {Accelerometer Z} */}
        <div className="container mt-2"></div> 
        <div className="col-md-4">
          <div className="category">
            <div className="card">
              <div className="card-body4">
                <h5 className="card-title">Accelerometer Z (AZ)</h5>
                  <p className="card-text">{azValue ? `${azValue} unit` : "No data"}</p>
                  </div>
                </div>
              </div>
            </div>


        {/* {Accelerometer Z} */} 
        <div className="container mt-2"></div>            
        <div className="col-md-4">
            <div className="category">
                <div className="card">
                    <div className={"card-body"}>
                        <h5 className="card-title">Live Electrodermal Activity Graph "AZ"</h5>
                        <div className="chart-container">
                            <LineChart width={350} height={280} data={azValue1}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="x" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="y" strokeWidth={2}/>
                            </LineChart>
                        </div>
                    </div>
              </div>
            </div>
        </div>
        </div>
        </div>
        </section>
        </div>
        </div>


      {/* Footer section */}
      <footer className="footer">
        <div className="container">
          <span className="text-muted">Enchanite Footer</span>
        </div>
      </footer>
    </>
  );

  

  
}

export default ClinicDashboard;