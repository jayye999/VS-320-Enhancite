import React from 'react';
import enhanciteImage from '../view/Images/Enhancite_Transparent.png'; // Import the image

function ThresholdPopup({maxThreshHold, onClose}) {

    const endExercise = () => {
        onClose();
    };

    const continueExercise = () => {
        onClose();
    }

    const labelStyle = {fontFamily: 'sans-serif'};
    const buttonStyle = {fontFamily: 'sans-serif'};
    const labelInputSpacing = {margin: '10px 0'};
    const inputSpacing = {margin: '0 10px'};

    return (
        <div className="popup-container">
            <div className="thresh-popup-content">
                <div className="top-Image-pop">
                    <img
                        src={enhanciteImage}
                        alt="Enhancite Logo"
                        className="small-image"
                    />
                </div>
                <h2>Thresh Hold Pop Up</h2>
                <div className="thresh-line">
                    <label htmlFor="threshHold" style={{...labelStyle, ...labelInputSpacing}}>
                        Thresh Hold:
                    </label>
                    <div id='threshHold' style={inputSpacing}>{maxThreshHold}</div>
                </div>
                <div className="thresh-buttons">
                    <button className="create-account-button" onClick={continueExercise} style={buttonStyle}>
                        Continue exercise
                    </button>
                    <button className="close-button" onClick={endExercise} style={buttonStyle}>
                        End exercise
                    </button>
                </div>
            </div>
        </div>
    );
}

export default ThresholdPopup;