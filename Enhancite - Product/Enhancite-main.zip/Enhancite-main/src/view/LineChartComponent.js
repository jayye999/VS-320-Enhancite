import React from 'react';
import {Legend, Line, LineChart, Tooltip, XAxis, YAxis} from 'recharts';

function LineChartComponent({data}) {
    console.log('Data prop in LineChartComponent:', data);

    if (!data || data.length === 0) {
        return <div>No data available.</div>;
    }

    return (
        <LineChart width={275} height={200} data={data}>
            <XAxis dataKey="dateTimeRecorded" type="number" domain={['dataMin', 'dataMax']}
                   tickFormatter={(value) => new Date(value).toLocaleString()}/>
            <YAxis dataKey="value"/>
            <Tooltip/>
            <Legend/>
            <Line type="monotone" dataKey="value" stroke="#8884d8"/>
        </LineChart>
    );
}

export default LineChartComponent;