import React, {useState} from 'react';
import './Style.css';
import enhanciteImage from './Images/Enhancite_Transparent.png';
import {useHistory} from 'react-router-dom';
import axios from 'axios';

function status() {
    //implement the function to see whether or not the user has indeed been deleted
    //if yes, display "Removed Successfully" in green writing (bold weight)
    //if no, dislay "Removed Unsuccessfully" in red writing (bold weight)
}

function AdminDashboard() {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [password, setPassword] = useState('');
    const [email, setEmail] = useState('');
    const [clinicName, setClinicName] = useState('');


    // const [deleteFirstName, setDeleteFirstName] = useState('');
    // const [deleteLastName, setDeleteLastName] = useState('');
    const [deleteClicianId, setDeleteClicianId] = useState('');

    const handleCreateFirstNameChange = (e) => {
        setFirstName(e.target.value);
    };

    const handleCreateLastNameChange = (e) => {
        setLastName(e.target.value);
    };

    const handleCreateEmailChange = (e) => {
        setEmail(e.target.value);
    };

    const handleCreateCliNameChange = (e) => {
        setClinicName(e.target.value);
    };

    const handleCreatePasswordChange = (e) => {
        setPassword(e.target.value);
    };

    // const handleDeleteFirstNameChange = (e) => {
    //     setDeleteFirstName(e.target.value);
    // };

    // const handleDeleteLastNameChange = (e) => {
    //     setDeleteLastName(e.target.value);
    // };

    const handleDeleteClicianIdChange = (e) => {
        setDeleteClicianId(e.target.value);
    };

    const history = useHistory();

    const handleLogout = () => {
        history.goBack();
    };

    // const axios = require('axios');
    // Define the URL of your API endpoint
    const apiUrl = 'http://3.27.158.164:8080/auth/clinician';
    // Define the request data and headers
    const requestData = {
        firstName: firstName,
        lastName: lastName,
        email: email,
        password: password,
        clinicName: 'Wangaratta Medical Centre'
    };
    const headers = {
        'Content-Type': 'application/json'
    };

    const handleCreateClinician = () => {
        console.log('Create Clinician button clicked');
        // Make the POST request
        axios.post(apiUrl, requestData, {headers})
            .then(response => {
                console.log('Clinician Registration Response:', response.data);
            })
            .catch(error => {
                console.error('Error:', error);
            });
    };

    const handleDeleteClinician = () => {
        console.log('Delete Clinician button clicked');
        const deletApiUrl = 'http://3.27.158.164:8080/clinician/' + deleteClicianId;
        axios.delete(deletApiUrl, {
            headers
        }).then(response => {
            console.log('Clinician Registration Response:', response.data);
        })
            .catch(error => {
                console.error('Error:', error);
            });
    };

    return (
        <div className="PatientDashboard">
            <button className="logout-button" onClick={handleLogout}>
                Logout
            </button>


            <div className="Header">
                <div className="banner-image">
                    <img src={enhanciteImage} alt="Enhancite Logo" className="logo-image"/>
                </div>
            </div>


            <main>
                <div className="Admin-Create-Account-lbl">Create Account</div>

                <div className="Admin-EnterFName">Enter Clinician First Name
                    <input className="input-field-adminFnm"
                           type="text"
                           placeholder="Enter First Name"
                           value={firstName}
                           onChange={handleCreateFirstNameChange}
                    />
                </div>


                <div className="Admin-EnterLName">Enter Clinician Last Name
                    <input className="input-field-adminLnm"
                           type="text"
                           placeholder="Enter Last Name"
                           value={lastName}
                           onChange={handleCreateLastNameChange}
                    />
                </div>

                <div className="Admin-EnterEmail">Enter Clinician Email
                    <input className="input-field-adminEma"
                           type="text"
                           placeholder="Enter Email"
                           value={email}
                           onChange={handleCreateEmailChange}
                    />
                </div>


                <div className="Admin-EnterPword">Enter Clinician Password
                    <input className="input-field-adminPwd"
                           type="password"
                           placeholder="Enter Password"
                           value={password}
                           onChange={handleCreatePasswordChange}
                    />
                </div>

                <div className="Admin-EnterName">Enter Clinician Name
                    <input className="input-field-adminName"
                           type="text"
                           placeholder="Enter Clinician Name"
                           value={clinicName}
                           onChange={handleCreateCliNameChange}
                    />
                </div>

                <div className="Admin-AddNewAdmin">
                    <button className="Admin-AddClinician" onClick={handleCreateClinician}>
                        Add
                    </button>
                </div>

                <div className="Admin-Delete-Account-lbl">Delete Account</div>
                {/*
        <div className="AdminD-EnterFName">Enter Clinician First Name
        <input className="input-field-DFnm" 
          type="text"
          placeholder="Enter First Name"
          value={deleteFirstName}
          onChange={handleDeleteFirstNameChange}
        />
        </div> */}


                {/* <div className="AdminD-EnterLName">Enter Clinician Last Name
        <input className="input-field-DLnm"
          type="text"
          placeholder="Enter Last Name"
        
          value={deleteLastName}
          onChange={handleDeleteLastNameChange}
        />
        </div> */}

                <div className="AdminD-EnterMName">Enter Clinician Id
                    <input className="input-field-DLnm"
                           type="text"
                           placeholder="Enter Clinician Id"

                           value={deleteClicianId}
                           onChange={handleDeleteClicianIdChange}
                    />
                </div>


                <div className="Admin-DeleteAdmin">
                    <button className="Admin-DeleteClinician" onClick={handleDeleteClinician}>
                        Remove
                    </button>
                </div>

            </main>
        </div>
    );
}

export default AdminDashboard;
