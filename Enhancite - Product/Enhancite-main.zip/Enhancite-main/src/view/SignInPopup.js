import React, {useState} from 'react';
import {useHistory} from 'react-router-dom';
import UserIcon from './Images/UserIcon.png';
import PasswordIcon from './Images/PasswordIcon.jpg';
import axios from 'axios';

function SignInPopup({isOpen, onClose}) {
    const history = useHistory();
    const [formData, setFormData] = useState({
        email: '',
        passwordProvided: '',
    });

    const handleChange = (e) => {
        const {name, value} = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    // Define the URL of your API endpoint
    const apiUrl = 'http://3.27.158.164:8080/auth/login';

    const headers = {
        'Content-Type': 'application/json'
    };

    const handleSignIn = () => {
        // Implement your sign-in logic here using formData
        console.log('Sign In Data:', formData);

        // Make the POST request to log in the patient
        axios.post(apiUrl, formData, {headers})
            .then(response => {
                if (response.status === 200) {
                    console.log('Login successful');
                    // You can access user data from response.data, if provided
                    history.push('/PatientDashboard');
                } else {
                    console.log('Login failed');
                }
            })
            .catch(error => {
                // history.push('/PatientDashboard');
                console.error('Error:', error);
            });

        // Use history to navigate to the Patient Dashboard upon successful login
        // Close the popup after signing in
        onClose();
    };


    const labelStyle = {fontFamily: 'sans-serif'};
    const buttonStyle = {fontFamily: 'sans-serif'};
    const labelInputSpacing = {margin: '10px 0'};
    const inputSpacing = {margin: '0 10px'};

    return (
        <div className="popup-container">
            {isOpen && (
                <div className="popup-content">
                    <h2 className="LoginLabel4Popup">Login</h2>
                    <div className="form-group">
                        <img src={UserIcon} alt="User Icon"
                             style={{width: '20px', height: '20px', marginRight: '10px'}}/>
                        <label htmlFor="email" style={{...labelStyle, ...labelInputSpacing}}>
                            Email:
                        </label>
                        <input
                            type="text"
                            id="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            style={inputSpacing}
                        />
                    </div>
                    <div className="form-group">
                        <img src={PasswordIcon} alt="Password Icon"
                             style={{width: '20px', height: '20px', marginRight: '10px'}}/>
                        <label htmlFor="passwordProvided" style={{...labelStyle, ...labelInputSpacing}}>
                            Password:
                        </label>
                        <input
                            type="password"
                            id="passwordProvided"
                            name="passwordProvided"
                            value={formData.passwordProvided}
                            onChange={handleChange}
                            style={inputSpacing}
                        />
                    </div>
                    <div className="form-buttons">
                        <button className="login-button" onClick={handleSignIn} style={buttonStyle}>
                            Login
                        </button>
                        <button className="close-button" onClick={onClose} style={buttonStyle}>
                            Close
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}

export default SignInPopup;