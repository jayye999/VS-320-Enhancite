import React, {useState} from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import './view/Style.css';
import enhanciteImage from './view/Images/Enhancite_Transparent.png';
import SignInPopup from './view/SignInPopup.js';
import SignUpPopup from './view/SignUpPopup.js';
import ClinSignInPopup from './view/ClinSignInPopup.js';
import AdminSignInPopup from './view/AdminSignInPopup.js';
import AdminDashboard from './view/AdminDashboard.js'; // Import the AdminDashboard component
import ClinicDashboard from './view/ClinicDashboard';
import PatientDashboard from './view/PatientDashboard';

function Index() {
    const [isSignInPopupOpen, setIsSignInPopupOpen] = useState(false);
    const [isSignUpPopupOpen, setIsSignUpPopupOpen] = useState(false);
    const [isClinSignInPopupOpen, setIsClinSignInPopupOpen] = useState(false);
    const [isAdminSignInPopupOpen, setIsAdminSignInPopupOpen] = useState(false);

    const openSignInPopup = () => {
        setIsSignInPopupOpen(true);
    };

    const openSignUpPopup = () => {
        setIsSignUpPopupOpen(true);
    };
    const openClinSignInPopup = () => {
        setIsClinSignInPopupOpen(true);
    };
    const openAdminSignInPopup = () => {
        setIsAdminSignInPopupOpen(true);
    };

    const closePopup = () => {
        setIsSignInPopupOpen(false);
        setIsSignUpPopupOpen(false);
        setIsClinSignInPopupOpen(false);
        setIsAdminSignInPopupOpen(false);
    };

    return (
        <div className="Index">
            <div className="Header"></div>
            <div className='IndexHeader'></div>
            <main>
                <div className="centered-image">
                    <img
                        src={enhanciteImage}
                        alt="Enhancite Logo"
                        className="small-image"
                    />
                </div>

                <div className="button-container">
                    <button className="gray-button" onClick={openSignInPopup}>Patient Login</button>
                    <button className="gray-button" onClick={openSignUpPopup}>Patient Sign Up</button>
                    <button className="gray-button" onClick={openClinSignInPopup}>Clinician Login</button>
                    <button className="gray-button" onClick={openAdminSignInPopup}>Admin Login</button>
                </div>
            </main>
            <footer className="footer-banner"></footer>
            {isSignInPopupOpen && (
                <SignInPopup isOpen={isSignInPopupOpen} onClose={closePopup}/>
            )}

            {isSignUpPopupOpen && (
                <SignUpPopup isOpen={isSignUpPopupOpen} onClose={closePopup}/>
            )}
            {isClinSignInPopupOpen && (
                <ClinSignInPopup isOpen={isClinSignInPopupOpen} onClose={closePopup}/>
            )}
            {isAdminSignInPopupOpen && (
                <AdminSignInPopup isOpen={isAdminSignInPopupOpen} onClose={closePopup}/>
            )}
        </div>
    );
}

function App() {
    return (
        <Router>
            <Switch>
                <Route path="/AdminDashboard" component={AdminDashboard}/>
                <Route path="/ClinicDashboard" component={ClinicDashboard}/>
                <Route path="/PatientDashboard" component={PatientDashboard}/>
                <Route path="/" component={Index}/>
            </Switch>
        </Router>
    );
}

ReactDOM.render(<App/>, document.getElementById('root'));
